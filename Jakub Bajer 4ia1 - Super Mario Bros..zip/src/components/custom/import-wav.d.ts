declare module "*.wav" {
  const value: any;
  export default value;
}