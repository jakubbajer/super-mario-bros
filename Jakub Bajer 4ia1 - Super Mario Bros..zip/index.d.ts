declare module '*.png';
declare module '*.jpg';
declare module '*.mp3';
declare module '*.wav';